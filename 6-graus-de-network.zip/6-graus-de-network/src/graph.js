const fs = require('fs');
const path = require('path');

class Graph {
  constructor() {
    this.adjacencyList = {};
  }

  addVertex(vertex) {
    if (!this.adjacencyList[vertex]) {
      this.adjacencyList[vertex] = new Set();
    }
  }

  addEdge(vertex1, vertex2) {
    this.addVertex(vertex1);
    this.addVertex(vertex2);
    this.adjacencyList[vertex1].add(vertex2);
    this.adjacencyList[vertex2].add(vertex1); // grafo não direcionado
  }

  show() {
    for (let vertex in this.adjacencyList) {
      console.log(`${vertex} => ${[...this.adjacencyList[vertex]].join(', ')}`);
    }
  }

  getVertices() {
    return Object.keys(this.adjacencyList);
  }

  getAdjacencyList() {
    return this.adjacencyList;
  }
}

function seedGraphFromJSON(filepath) {
  const rawData = fs.readFileSync(filepath);
  const movies = JSON.parse(rawData);
  const graph = new Graph();

  for (const movie of movies) {
    const movieTitle = movie.title;
    graph.addVertex(movieTitle);

    for (const actor of movie.cast) {
      graph.addEdge(movieTitle, actor);
    }
  }

  return graph;
}

module.exports = { Graph, seedGraphFromJSON };