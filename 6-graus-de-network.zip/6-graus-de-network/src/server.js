
const express = require('express');
const cors = require('cors');
const path = require('path');
const { seedGraphFromJSON } = require('./graph');
const { bfs, bfsAllPaths } = require('./bfs');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

const graph = seedGraphFromJSON(path.join(__dirname, '../data/latest_movies.json'));
const adjacencyList = graph.getAdjacencyList();

app.get('/actors', (req, res) => {
  const vertices = graph.getVertices();
  const movies = new Set();

  for (const movie of Object.keys(adjacencyList)) {
    for (const neighbor of adjacencyList[movie]) {
      if (adjacencyList[neighbor].has(movie)) {
        movies.add(movie);
      }
    }
  }

  const actors = vertices.filter(v => !movies.has(v));
  res.json(actors.sort());
});

app.post('/search', (req, res) => {
  const { from, to } = req.body;
  const path = bfs(adjacencyList, from, to);
  if (path) {
    res.json({ path, length: path.length - 1 });
  } else {
    res.json({ path: null, message: 'Relacionamento não encontrado.' });
  }
});

app.post('/search-all', (req, res) => {
  const { from, to } = req.body;
  const paths = bfsAllPaths(adjacencyList, from, to, 6);
  if (paths.length > 0) {
    res.json({ paths });
  } else {
    res.json({ paths: [], message: 'Nenhum caminho encontrado com até 6 arestas.' });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
