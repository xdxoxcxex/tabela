
function bfs(graph, start, end, maxDepth = Infinity) {
  const visited = new Set();
  const queue = [[start]];

  while (queue.length > 0) {
    const path = queue.shift();
    const node = path[path.length - 1];

    if (node === end) return path;

    if (!visited.has(node) && path.length <= maxDepth + 1) {
      visited.add(node);

      const neighbors = graph[node] || [];
      for (const neighbor of neighbors) {
        const newPath = [...path, neighbor];
        queue.push(newPath);
      }
    }
  }
  return null; // caminho não encontrado
}

function bfsAllPaths(graph, start, end, maxDepth = 6) {
  const results = [];
  const visited = new Set();
  const queue = [[start]];

  while (queue.length > 0) {
    const path = queue.shift();
    const node = path[path.length - 1];

    if (node === end && path.length <= maxDepth + 1) {
      results.push(path);
      continue;
    }

    if (!visited.has(path.join('->'))) {
      visited.add(path.join('->'));
      const neighbors = graph[node] || [];

      for (const neighbor of neighbors) {
        if (!path.includes(neighbor)) {
          const newPath = [...path, neighbor];
          if (newPath.length <= maxDepth + 1) {
            queue.push(newPath);
          }
        }
      }
    }
  }

  return results;
}

module.exports = { bfs, bfsAllPaths };
